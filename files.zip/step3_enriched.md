# X-Rays

> **Physics Ebook Series - Chapter 4.8**  
> Each chapter is enriched with interactive Python code you can run immediately.


## Production of X-Rays


## Properties of X-Rays


## Energy of X-Rays


## Hard and Soft X-Rays


## Uses of X-Rays


## Dangers of X-Rays


## Worked Examples

### Example 1

Worked Examples
Example 1
Find the frequency and the energy of a type of X-rays whose wavelength is 10^(-10) m in a vacuum. (velocity of light c = 3.0 × 10⁸ ms^(-1), Planck's constant h = 6.63 × 10^(-34) Js).
Solution
c = fλ
3.0 × 10⁸ = 10^(-10)f
∴ f =
$$\frac{\ 3.0\ \times \ 10^{8}}{10^{- 10}\ }$$
= 3.0 × 10¹⁸ Hz
E = hf
= 6.63 × 10^(-34) × 3.0 × 10¹⁸
= 1.989 × 10^(-15) J
Example 2
The frequency of X-rays range from 3.0 × 10¹⁷ to 3.0 × 10¹⁹ Hz. Determine:
(a) the range of the wavelengths.
(b) the maximum energy of X-rays. (velocity of light, c = 3.0 × 10⁸ ms^(-1) and Planck's constant h = 6.63 × 10^(-34) Js)
Solution
(a) Let λ₁ and λ₂ be the wavelengths.
c = fλ₁
3.0 × 10⁸ = 3.0 × 10¹⁷ × λ₁
∴ λ₁ =
$$\frac{\ 3.0\ \times \ 10^{8}}{3.0\ \times \ 10^{17}\ }$$
= 1.0 × 10⁻⁹ m
Also, c = fλ₂
3.0 × 10⁸ = 3.0 × 10¹⁹λ₂
∴ λ₂ =
$$\frac{\ 3.0\ \times \ 10^{8}}{3.0\ \times \ 10^{19}\ }$$
= 1.0 × 10⁻¹¹ m
Thus, the range of the wavelengths is 10^(-11) m to 10^(-9) m
(b) The maximum energy is given by;
E_(max) = hf_(max)
= 6.63 × 10^(-34) × 3.0 × 10¹⁹
= 1.989 × 10^(-14) J
Example 3
An X-ray tube has an accelerating potential difference of 100 kV. What is the shortest wavelength in its X-ray beam? (Planck's constant h = 6.63 × 10^(-34) Js, charge on electron, e =1.6 × 10^(-19) C and velocity of light, c = 3.0 × 10⁸ ms^(-1))
Solution
eV = hf_(max) = h
$$\frac{c}{\lambda_{\min}}$$
λ_(min) =
$$\frac{hc}{eV} = \frac{6.63\ \times {\ 10}^{- 34} \times \ 3.0\ \times \ 10^{8}}{1.6\ \times \ 10^{- 19}\ \times \ 10^{5}}$$
= 1.24 × 10⁻¹¹ m
Hard and Soft X-rays
Hard X-rays are produced by fast moving electrons as a result of a high accelerating voltage. They have very short wavelength and thus high penetrating power. They can penetrate the flesh, but are absorbed by bones.
Soft X-rays are produced by electrons moving at relatively lower velocities than those that produce hard X-rays. They have less energy, longer wavelengths, hence less penetrating power compared to hard X-rays. They are used to show malignant growth in tissues, since they only penetrate soft flesh but are absorbed by such growths.
Intensity (Quantity) and Quality of X-rays
The intensity of X-rays is controlled by the heating current. The greater the heating current, the greater the number of electrons produced, hence the more the X-rays.
The strength (quality) of the X-rays depends on the speed of the electrons, which in turn depends on the accelerating potential difference between the cathode and the anode. The higher the accelerating p.d, the stronger the X-Rays produced.
Uses of X-rays
In Medicine (Radiography and Radiotherapy)
X-ray imaging is used to diagnose injuries to the liver, spleen, kidneys and other internal organs of people who have had accidents.
X-rays are also used for the treatment of tumors. In this regard, CT examinations are used to plan and properly administer radiation treatment for tumors.
During the X-ray photography, a point source of the X-rays is needed. This is because although X-rays travel in straight lines, unlike light they cannot be focused by lenses. For X-rays to produce shadows with sharp edges, the rays must come from a point source. The CT scan gives this readily.
X-rays are also used to detect foreign objects in the body, eg, safety pin if swallowed accidentally.
In Industry
X-rays are used to detect flaws in metal castings and welding. The radiation is also used to sterilise surgical equipment before packaging.
In Crystallography
X-rays are used to study the crystal structure of substances.
Security, e.g., in Airports
X-rays are used to inspect luggage for any weapons that may be hidden in them.
Dangers of X-rays
Excessive exposure of living tissue to X-rays is dangerous as the radiations can damage or kill cells.


## Review Questions

Specific Objectives

By the end of this topic, the learner should be able to:

a) explain the production of X-rays

b) state the properties of X-rays

c) state the dangers of X-rays

d) explain the uses of X-rays

e) solve numerical problems involving X-rays.

(8 Lessons)

Content


**1. Production of X-rays, X-ray tube**


**2. Energy changes in an X-ray tube**


**3. Properties of X-rays, soft X-rays and hard X-rays**


**4. Dangers of X-rays and precautions**


**5. Uses of X-rays(Bragg‟s law not required)**


**6. Problems on X-rays**

X-rays is an electromagnetic radiation that was discovered accidentally by Rontgen, a German, while conducting research on cathode rays. X-rays owe their name to the fact that at the time of their discovery, their nature was unknown.

It is now known that X-rays are produced when fast moving electrons are suddenly stopped by matter.

Production of X-rays

X-rays are produced in X-ray tubes where fast moving electrons are suddenly stopped on hitting metal targets.

An X-ray tube is shown below. []

When a current flows through the filament in the cathode, electrons are produced by thermionic emission. The electrons are accelerated towards the target (anode) by the high potential difference of the order 100 kV between the cathode and the anode. The cathode is concave shaped so as to focus the electron beam onto the target, which is usually of tungsten embedded onto copper.

Most of the kinetic energy of the electron is converted to heat, with only about 0.5 % being transformed to X-rays radiation. The target must therefore be a metal of high melting point, such as tungsten or molybdenum.

The anode is made of a good conductor of heat, e.g., copper, to ensure efficient dissipation of heat. Cooling is further enhanced by the cooling fins on the outside of the tube and circulation of oil through the channels in the copper block (anode).

In more recent models, the target rotates during operation to change the point of impact, thereby reducing the wear and tear on it. The tube is made of strong glass highly evacuated so that electrons do not lose some of their energy through collision with air molecules on their way to the target.

During the half-cycle when the anode is positive with respect to the cathode, electrons are accelerated towards the target and X-rays are produced when bombardment takes place. In the reverse half-cycle, the anode is negative with respect to the cathode. Electrons do not move to the target and therefore bombardment does not take place, hence X-rays are not produced in this reverse cycle. X-rays are therefore produced in bursts, that is, only in those half-cycles when the anode is positive with respect to the cathode. However, due to the high frequency of a.c., the X-rays production appears to be continuous.

Properties of X-rays

(i) X-rays are not deflected by magnetic or electric fields. They are therefore not charged.

(ii) They penetrate matter, with the least penetration occurring in materials of high density, e.g., lead.

(iii) X-rays affect photographic emulsions, a property used in X-ray photography.

(iv) In moving through air, they can knock off electrons from the molecules on their path. They therefore ionise air molecules and so increase the conductivity of gases.

(v) They cause photoelectric emission.

(vi) They cause fluorescence in certain substances, e.g., zinc sulphide.

(vii) They are electromagnetic radiations of shorter wavelength than visible light. They can be plane-polarised and diffracted, showing that they are waves in nature.

(viii) They travel in straight lines at the speed of light (3.0 × 10⁸ ms⁻¹).

X-rays as Part of Electromagnetic Spectrum

X-rays are electromagnetic waves of very short wavelength, of the order of 10^(-10) m. For classification purposes, electromagnetic waves in the appropriate range of 10^(-11) to 10^(-8) m are considered as X-rays. This range overlaps with the ultraviolet at the upper end and gamma rays at the lower end, the only difference being only in the manner of production of each.

Energy of X-rays

If a bombarding electron is stopped in a single collision most or all of its energy is converted to X-ray energy.

At a given accelerating potential difference, the X-rays produced will have varying wavelengths, with the shortest (λ_(min)) corresponding to a collision in which all the energy is assumed to have been converted to X-rays.

The kinetic energy (K.E.) of the bombarding electron is practically equal to eV and is given by;

K.E. = eV,

where e is the electron charge and V the accelerating potential difference.

When all the kinetic energy of an electron is used to produce the X-ray energy, the frequency of the X-rays will be maximum (f_(max)).

Using Planck's theory, the X-ray energy is given by;

E = hf, where h is Planck's constant and f the frequency of radiation.

Thus, eV = hf_(max)

Since c = fλ, where c is the velocity of light;

f_(max) =

$$\frac{c}{\lambda_{\min}\ }$$

, where λ_(min) is the minimum wavelength.

∴ eV = h

$$\frac{\ c}{\lambda_{\min}\ }$$

= 1.0 × 10⁻⁹ m

This shows that the most energetic X-rays have the shortest wavelength.

Take electron mass = 9.1 × 10^(-31) kg, e = 1.6 × 10^(-19) C, h = 6.63 × 10^(-34) Js and c = 3.0 × 10⁸ ms^(-1)


**1. (a) How are X-rays produced ?**

(b) How can the intensity of an X-ray beam be increased?

(c) State four uses of X-rays.

(d) Distinguish between hard and soft X-rays.


**2. (a) Why is it difficult to verify the wave nature of X-rays by refraction experiment?**

(b) What is the minimum possible wavelength of X-rays produced in an X-ray tube operating at 10 kV?

(c) Calculate the energy gained in (b) above when the operating voltage is raised to 100 kV?


**3. (a) State the features which facilitate efficient cooling of the anode during the operation of an X-ray tube. Briefly explain how they achieve cooling of the anode.**

(b) Briefly describe an experiment to show that X-rays are not charged particles.


**4. (a) State three properties that confirm X-rays as part of the electromagnetic spectrum.**

(b) An X-ray tube operating at 50 kV has a tube current of 20 mA.

(i) How many electrons are hitting the target per second?

(ii) If only 0.5 % of the energy of the electrons is converted to X-rays, estimate the quantity of heat produced per second.

(iii) Find the X-ray power output.


**5. An X-ray tube operates at a potential of 80 kV. Only 0.5 % of the electron energy is converted to X-rays, while heat is generated at the anode at the rate of 100 Js⁻¹. Determine:**

(a) the tube current.

(b) the average velocity of the electrons hitting the target.

(c) the minimum wavelength of the X-rays.


---

## Further Reading

- [NIST X-Ray Transition Energies Database](https://physics.nist.gov/PhysRefData/XrayTrans/Html/search.html)
- [HyperPhysics - X-ray Production](http://hyperphysics.phy-astr.gsu.edu/hbase/quantum/xrayc.html)
- [Khan Academy - Radiology and X-rays](https://www.khanacademy.org/science/health-and-medicine/radiology)
- [Wikipedia - X-ray](https://en.wikipedia.org/wiki/X-ray)
