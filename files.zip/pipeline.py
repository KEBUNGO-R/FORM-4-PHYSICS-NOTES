"""
Physics Ebook → Blog Pipeline
==============================
Steps 1-5: Extract -> Transform -> Enrich -> Generate metadata -> Publish

Usage:
    # Dry run (preview, no publish):
    python pipeline.py --file "4_8_X-Rays.docx"

    # Publish live to Hashnode:
    python pipeline.py --file "4_8_X-Rays.docx" --publish \
        --token "YOUR_TOKEN" --publication-id "YOUR_PUB_ID"

Dependencies (install with pip):
    pip install markdown2 requests
    pandoc  (system package: https://pandoc.org/installing.html)
"""

import argparse
import json
import re
import subprocess
import textwrap
from datetime import datetime
from pathlib import Path


# ================================================================
# STEP 1 - EXTRACT
# Use pandoc to read the .docx, then parse into structured sections.
# ================================================================

def extract_from_docx(filepath: str) -> dict:
    result = subprocess.run(
        ["pandoc", filepath, "-t", "plain", "--wrap=none"],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        raise RuntimeError(f"pandoc failed: {result.stderr}")

    lines = [ln.rstrip() for ln in result.stdout.splitlines()]

    KNOWN_HEADINGS = {
        "Production of X-rays", "Properties of X-rays",
        "X-rays as Part of Electromagnetic Spectrum",
        "Energy of X-rays", "Hard and Soft X-rays",
        "Intensity (Quantity) and Quality of X-rays",
        "Uses of X-rays", "Dangers of X-rays",
    }
    HEADING_KEYWORDS = [
        "X-ray", "Production", "Properties", "Energy",
        "Hard", "Soft", "Intensity", "Uses", "Dangers",
        "Spectrum", "Quality", "Electromagnetic"
    ]

    data = {
        "title": "X-Rays",
        "objectives": [],
        "sections": [],
        "examples": [],
        "review_questions": [],
    }

    current_section = None
    current_example = []
    mode = "body"
    seen_headings = set()

    for line in lines:
        line = line.strip()
        if not line or line.startswith("[]") or re.match(r'!\[', line):
            continue

        # Objectives
        if re.match(r'^[a-e]\)\s+\w', line) and not data["sections"]:
            data["objectives"].append(re.sub(r'^[a-e]\)\s+', '', line))
            continue

        # Skip TOC duplicates
        if line in KNOWN_HEADINGS and not data["sections"]:
            continue

        # Worked examples
        if re.match(r'Worked Example|^\*+Example\s+\d|\*Worked', line, re.I):
            mode = "example"
            current_example = [line]
            continue

        # Review / Revision exercise
        if re.match(r'Review\s+Exercise|Revision\s+Exercise|Recently', line, re.I):
            if current_example:
                data["examples"].append("\n".join(current_example))
                current_example = []
            mode = "review"
            continue

        if mode == "review":
            data["review_questions"].append(line)
            continue

        if mode == "example":
            current_example.append(line)
            continue

        # Detect section headings
        is_heading = (
            line in KNOWN_HEADINGS or (
                len(line) < 72 and
                not line.endswith(".") and
                not re.match(r'^\d+[.\)]', line) and
                len(line.split()) <= 9 and
                line[0].isupper() and
                any(kw in line for kw in HEADING_KEYWORDS)
            )
        )

        if is_heading and line not in seen_headings:
            seen_headings.add(line)
            if current_section:
                data["sections"].append(current_section)
            current_section = {"heading": line, "paragraphs": []}
            continue

        if current_section and len(line) > 20:
            current_section["paragraphs"].append(line)

    if current_section:
        data["sections"].append(current_section)
    if current_example:
        data["examples"].append("\n".join(current_example))

    return data


# ================================================================
# STEP 2 - TRANSFORM
# Build a clean Markdown document from the extracted data.
# ================================================================

def clean(text: str) -> str:
    text = text.replace('\u2019', "'").replace('\u201c', '"').replace('\u201d', '"')
    text = text.replace('\u2013', '-').replace('\u2014', '--')
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def transform_to_markdown(data: dict) -> str:
    lines = []

    lines.append(f"# {data['title']}\n")
    lines.append(
        "> **Physics Ebook Series - Chapter 4.8**  \n"
        "> Each chapter is enriched with interactive Python code you can run immediately.\n"
    )

    if data["objectives"]:
        lines.append("## Learning Objectives\n")
        lines.append("By the end of this chapter you should be able to:\n")
        for obj in data["objectives"]:
            lines.append(f"- {clean(obj)}")
        lines.append("")

    for section in data["sections"]:
        lines.append(f"\n## {clean(section['heading'])}\n")
        for para in section["paragraphs"]:
            p = clean(para)
            if p:
                lines.append(p + "\n")

    if data["examples"]:
        lines.append("\n## Worked Examples\n")
        for i, ex in enumerate(data["examples"], 1):
            lines.append(f"### Example {i}\n")
            ex_lines = [clean(ln) for ln in ex.splitlines() if ln.strip()]
            lines.append("\n".join(ex_lines) + "\n")

    if data["review_questions"]:
        lines.append("\n## Review Questions\n")
        for q in data["review_questions"]:
            q = clean(q)
            if not q:
                continue
            if re.match(r'^\d+\.', q):
                lines.append(f"\n**{q}**\n")
            else:
                lines.append(f"{q}\n")

    return "\n".join(lines)


# ================================================================
# STEP 3 - ENRICH
# Inject Python code snippets after relevant section headings.
# ================================================================

ENRICHMENTS = {
    "Energy of X-rays": textwrap.dedent("""
        > **Try it in Python** - paste this into any Python environment:

        ```python
        # X-ray energy calculator
        h = 6.63e-34   # Planck's constant  (J.s)
        c = 3.0e8      # Speed of light     (m/s)
        e = 1.6e-19    # Electron charge    (C)

        voltage_kV = 100                   # Change this value to explore
        V          = voltage_kV * 1000     # Convert kV to Volts

        lambda_min = (h * c) / (e * V)    # Minimum wavelength (m)
        f_max      = c / lambda_min        # Maximum frequency  (Hz)
        E_max      = h * f_max             # Maximum photon energy (J)

        print(f"Voltage   = {voltage_kV} kV")
        print(f"lambda_min = {lambda_min:.3e} m")
        print(f"f_max      = {f_max:.3e} Hz")
        print(f"E_max      = {E_max:.3e} J  ({E_max / e / 1000:.1f} keV)")
        ```

        **Key formula:** `lambda_min = hc / eV` - higher voltage means shorter wavelength and more energetic X-rays.
    """).strip(),

    "Hard and Soft X-rays": textwrap.dedent("""
        > **Python classifier** - determine X-ray type from wavelength:

        ```python
        def classify_xray(wavelength_m: float) -> str:
            if wavelength_m < 1e-11:
                return "Gamma / very hard X-ray"
            elif wavelength_m < 1e-10:
                return "Hard X-ray (high penetrating power - reaches bone)"
            elif wavelength_m < 1e-9:
                return "Soft X-ray (lower penetrating power - detects soft tissue)"
            else:
                return "UV boundary - not an X-ray"

        samples = [1.24e-11, 5e-11, 1.0e-10, 5e-10]
        for lam in samples:
            print(f"wavelength = {lam:.2e} m  ->  {classify_xray(lam)}")
        ```
    """).strip(),

    "Uses of X-rays": textwrap.dedent("""
        > **Python reference table** - a quick-reference summary of X-ray applications:

        ```python
        uses = [
            ("Medicine - Radiography",  "Detects fractures, foreign objects, organ damage"),
            ("Medicine - Radiotherapy", "Treats tumours via CT-guided radiation"),
            ("Industry",                "Detects flaws in metal castings and welds"),
            ("Crystallography",         "Determines crystal structure of substances"),
            ("Security",                "Airport baggage screening"),
        ]

        print(f"{'Field':<30} Application")
        print("-" * 72)
        for field, app in uses:
            print(f"{field:<30} {app}")
        ```
    """).strip(),
}

FURTHER_READING = [
    ("NIST X-Ray Transition Energies Database",
     "https://physics.nist.gov/PhysRefData/XrayTrans/Html/search.html"),
    ("HyperPhysics - X-ray Production",
     "http://hyperphysics.phy-astr.gsu.edu/hbase/quantum/xrayc.html"),
    ("Khan Academy - Radiology and X-rays",
     "https://www.khanacademy.org/science/health-and-medicine/radiology"),
    ("Wikipedia - X-ray",
     "https://en.wikipedia.org/wiki/X-ray"),
]


def enrich_markdown(md: str) -> str:
    for heading, block in ENRICHMENTS.items():
        md = re.sub(
            rf'(## {re.escape(heading)}\n)',
            r'\1\n' + block + '\n\n',
            md
        )
    fr = "\n\n---\n\n## Further Reading\n\n"
    for title, url in FURTHER_READING:
        fr += f"- [{title}]({url})\n"
    md += fr
    return md


# ================================================================
# STEP 4 - GENERATE METADATA + HTML
# Auto-generate slug, tags, excerpt, read-time, and an HTML preview file.
# ================================================================

def slugify(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r'[^\w\s-]', '', text)
    text = re.sub(r'[\s_-]+', '-', text)
    return text.strip('-')


def generate_metadata(data: dict, markdown: str) -> dict:
    title = data["title"] or "Physics: X-Rays"
    slug  = slugify(title)
    tags  = {"physics", "education", "science", "ebook"}
    for s in data["sections"]:
        h = s["heading"].lower()
        if "production"          in h: tags.add("x-ray-tube")
        if "properties"          in h: tags.add("electromagnetic-radiation")
        if "energy"              in h: tags.add("quantum-physics")
        if "uses"                in h: tags.add("medical-physics")
        if "danger"              in h: tags.add("radiation-safety")
        if "hard" in h or "soft" in h: tags.add("radiography")

    excerpt = ""
    for s in data["sections"]:
        for p in s["paragraphs"]:
            p = clean(p)
            if len(p) > 100:
                excerpt = p[:220] + "..."
                break
        if excerpt:
            break

    wc = len(markdown.split())
    return {
        "title":         title,
        "slug":          slug,
        "tags":          sorted(tags),
        "excerpt":       excerpt,
        "word_count":    wc,
        "read_time_min": max(1, round(wc / 200)),
        "published_at":  datetime.utcnow().isoformat() + "Z",
        "series":        "Physics Ebook",
        "chapter":       "4.8",
    }


def markdown_to_html(md: str) -> str:
    try:
        import markdown2
        return markdown2.markdown(
            md,
            extras=["fenced-code-blocks", "tables", "header-ids",
                    "strike", "cuddled-lists"]
        )
    except ImportError:
        # Built-in minimal converter
        html = md
        html = re.sub(r'^# (.+)$',   r'<h1>\1</h1>', html, flags=re.M)
        html = re.sub(r'^## (.+)$',  r'<h2>\1</h2>', html, flags=re.M)
        html = re.sub(r'^### (.+)$', r'<h3>\1</h3>', html, flags=re.M)
        html = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', html)
        html = re.sub(r'```[\w]*\n(.*?)```', r'<pre><code>\1</code></pre>', html, flags=re.S)
        html = re.sub(r'`([^`]+)`', r'<code>\1</code>', html)
        html = re.sub(r'^> (.+)$',   r'<blockquote>\1</blockquote>', html, flags=re.M)
        html = re.sub(r'^- (.+)$',   r'<li>\1</li>', html, flags=re.M)
        html = re.sub(r'\[(.+?)\]\((.+?)\)', r'<a href="\2">\1</a>', html)
        html = re.sub(r'\n\n+', '</p><p>', html)
        return f"<p>{html}</p>"


HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{title}</title>
  <style>
    *, *::before, *::after {{ box-sizing: border-box; }}
    body {{
      font-family: Georgia, serif; max-width: 820px;
      margin: 0 auto; padding: 40px 24px;
      line-height: 1.8; color: #1a1a1a; background: #fafaf8;
    }}
    h1 {{ font-size: 2.1em; border-bottom: 3px solid #1a3a6b;
          padding-bottom: 12px; color: #0d1f3c; }}
    h2 {{ font-size: 1.4em; color: #1a3a6b; margin-top: 2.4em;
          border-left: 4px solid #1a3a6b; padding-left: 12px; }}
    h3 {{ font-size: 1.15em; color: #333; margin-top: 1.6em; }}
    .meta {{
      background: #eef2fb; border-radius: 8px;
      padding: 12px 18px; font-size: 0.88em; color: #555;
      margin-bottom: 2em; display: flex; gap: 16px; flex-wrap: wrap;
    }}
    .meta span {{ font-weight: 600; color: #1a3a6b; }}
    blockquote {{
      border-left: 4px solid #4a7cc7; background: #f0f4ff;
      margin: 1.4em 0; padding: 12px 18px;
      border-radius: 0 8px 8px 0; color: #333;
    }}
    pre {{
      background: #1e1e2e; color: #cdd6f4;
      padding: 1.2em 1.4em; border-radius: 10px;
      overflow-x: auto; font-size: 0.88em; line-height: 1.6;
      font-family: 'Courier New', monospace;
    }}
    code {{
      background: #eef2fb; padding: 2px 6px;
      border-radius: 4px; font-size: 0.9em; color: #c0392b;
    }}
    pre code {{ background: none; color: inherit; padding: 0; }}
    ul, ol {{ padding-left: 1.6em; }}
    li {{ margin: 4px 0; }}
    a {{ color: #1a3a6b; }}
    hr {{ border: none; border-top: 1px solid #ddd; margin: 2.5em 0; }}
    .footer {{
      margin-top: 3em; font-size: 0.85em; color: #888;
      border-top: 1px solid #eee; padding-top: 1em;
    }}
  </style>
</head>
<body>
  <div class="meta">
    <div>Series: <span>{series}</span></div>
    <div>Chapter: <span>{chapter}</span></div>
    <div>Read time: <span>~{read_time} min</span></div>
    <div>Words: <span>{word_count}</span></div>
    <div>Tags: <span>{tags}</span></div>
  </div>
  {body}
  <div class="footer">
    Generated by the Physics Ebook to Blog Pipeline | {date}
  </div>
</body>
</html>
"""


# ================================================================
# STEP 5 - PUBLISH to Hashnode (GraphQL API)
# ================================================================

HASHNODE_API = "https://gql.hashnode.com"

PUBLISH_MUTATION = """
mutation PublishPost($input: PublishPostInput!) {
  publishPost(input: $input) {
    post {
      id
      title
      slug
      url
      publishedAt
    }
  }
}
"""


def publish_to_hashnode(
    api_token: str,
    publication_id: str,
    title: str,
    content_markdown: str,
    metadata: dict,
    dry_run: bool = True,
) -> dict:
    """
    Publishes the post to Hashnode via GraphQL.

    How to get your credentials:
      1. API token:       hashnode.com > Account Settings > Developer > Personal Access Tokens
      2. Publication ID:  hashnode.com/YOUR_USERNAME > Dashboard > Settings > Publication ID
    """
    if dry_run:
        print("\n  [DRY RUN] Post is ready. Would publish with:")
        print(f"    Title:      {title}")
        print(f"    Slug:       {metadata['slug']}")
        print(f"    Tags:       {', '.join(metadata['tags'][:6])}")
        print(f"    Words:      {metadata['word_count']}")
        print(f"    Read time:  ~{metadata['read_time_min']} min")
        if metadata['excerpt']:
            print(f"    Excerpt:    {metadata['excerpt'][:90]}...")
        print("\n  To publish live:")
        print("    python pipeline.py --file YOUR.docx --publish \\")
        print("        --token YOUR_TOKEN --publication-id YOUR_PUB_ID")
        return {"dry_run": True}

    import requests
    variables = {
        "input": {
            "title":           title,
            "slug":            metadata["slug"],
            "contentMarkdown": content_markdown,
            "publicationId":   publication_id,
            "tags":            [{"slug": t, "name": t.replace("-", " ").title()}
                                for t in metadata["tags"][:5]],
            "subtitle":        metadata["excerpt"][:150],
            "publishedAt":     metadata["published_at"],
        }
    }
    resp = requests.post(
        HASHNODE_API,
        json={"query": PUBLISH_MUTATION, "variables": variables},
        headers={"Authorization": api_token, "Content-Type": "application/json"},
        timeout=30,
    )
    resp.raise_for_status()
    result = resp.json()
    if "errors" in result:
        raise RuntimeError(f"Hashnode API error: {json.dumps(result['errors'], indent=2)}")
    return result["data"]["publishPost"]["post"]


# ================================================================
# ORCHESTRATOR
# ================================================================

def run_pipeline(
    docx_path: str,
    hashnode_token: str = "",
    publication_id: str = "",
    dry_run: bool = True,
    output_dir: str = "output",
):
    out = Path(output_dir)
    out.mkdir(exist_ok=True)
    SEP = "-" * 52

    print(f"\n{SEP}")
    print("  Physics Ebook to Blog Pipeline  (5 steps)")
    print(f"{SEP}")

    # Step 1
    print("\n  Step 1  Extract content from .docx")
    data = extract_from_docx(docx_path)
    with open(out / "step1_extracted.json", "w") as f:
        json.dump(data, f, indent=2)
    print(f"    {len(data['sections'])} sections, {len(data['objectives'])} objectives, "
          f"{len(data['examples'])} example blocks, {len(data['review_questions'])} questions")
    print(f"    -> {out}/step1_extracted.json")

    # Step 2
    print("\n  Step 2  Transform to Markdown")
    markdown = transform_to_markdown(data)
    with open(out / "step2_post.md", "w") as f:
        f.write(markdown)
    print(f"    {len(markdown.split())} words")
    print(f"    -> {out}/step2_post.md")

    # Step 3
    print("\n  Step 3  Enrich with Python code blocks")
    enriched_md = enrich_markdown(markdown)
    with open(out / "step3_enriched.md", "w") as f:
        f.write(enriched_md)
    print(f"    {len(ENRICHMENTS)} code blocks injected, {len(FURTHER_READING)} further-reading links added")
    print(f"    -> {out}/step3_enriched.md")

    # Step 4
    print("\n  Step 4  Generate metadata and HTML preview")
    meta = generate_metadata(data, enriched_md)
    html_body = markdown_to_html(enriched_md)
    html_page = HTML_TEMPLATE.format(
        title=meta["title"],
        series=meta["series"],
        chapter=meta["chapter"],
        read_time=meta["read_time_min"],
        word_count=meta["word_count"],
        tags=", ".join(meta["tags"]),
        body=html_body,
        date=datetime.utcnow().strftime("%Y-%m-%d"),
    )
    with open(out / "step4_post.html", "w") as f:
        f.write(html_page)
    with open(out / "step4_metadata.json", "w") as f:
        json.dump(meta, f, indent=2)
    print(f"    Title:     {meta['title']}")
    print(f"    Slug:      {meta['slug']}")
    print(f"    Tags:      {', '.join(meta['tags'])}")
    print(f"    Read time: ~{meta['read_time_min']} min  |  {meta['word_count']} words")
    print(f"    -> {out}/step4_post.html")
    print(f"    -> {out}/step4_metadata.json")

    # Step 5
    print("\n  Step 5  Publish to Hashnode")
    if not hashnode_token or not publication_id:
        dry_run = True

    result = publish_to_hashnode(
        api_token=hashnode_token,
        publication_id=publication_id,
        title=meta["title"],
        content_markdown=enriched_md,
        metadata=meta,
        dry_run=dry_run,
    )

    if not dry_run and "url" in result:
        print(f"\n    Published! URL: {result['url']}")

    print(f"\n{SEP}")
    print("  All done! Output files saved in:", out)
    print(f"{SEP}\n")
    return result


# ================================================================
# CLI
# ================================================================

if __name__ == "__main__":
    ap = argparse.ArgumentParser(
        description="Physics Ebook to Blog Pipeline (Steps 1-5)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent("""
        Examples:
          python pipeline.py --file 4_8_X-Rays.docx
          python pipeline.py --file 4_8_X-Rays.docx --publish \\
              --token "ey..." --publication-id "64abc..."
        """)
    )
    ap.add_argument("--file",           required=True)
    ap.add_argument("--token",          default="",       help="Hashnode API token")
    ap.add_argument("--publication-id", default="",       help="Hashnode Publication ID")
    ap.add_argument("--output-dir",     default="output", help="Output folder")
    ap.add_argument("--publish",        action="store_true",
                    help="Publish live (without this flag runs as dry-run)")
    args = ap.parse_args()

    run_pipeline(
        docx_path=args.file,
        hashnode_token=args.token,
        publication_id=args.publication_id,
        dry_run=not args.publish,
        output_dir=args.output_dir,
    )
